import nltk

class Analyzer():
    """Implements sentiment analysis."""

    def __init__(self, positives, negatives):
        """Initialize Analyzer."""

        # TODO

    def analyze(self, text):
        """Analyze text for sentiment, returning its score."""

        # TODO
        return 0
